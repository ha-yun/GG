package com.example.msauserdemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MsaUserDemoApplication {

    public static void main(String[] args) {
        SpringApplication.run(MsaUserDemoApplication.class, args);
    }

}
