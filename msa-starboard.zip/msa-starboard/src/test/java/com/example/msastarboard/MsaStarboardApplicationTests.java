package com.example.msastarboard;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MsaStarboardApplicationTests {

    @Test
    void contextLoads() {
    }

}
