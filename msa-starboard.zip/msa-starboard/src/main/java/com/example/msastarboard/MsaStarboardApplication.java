package com.example.msastarboard;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MsaStarboardApplication {

    public static void main(String[] args) {
        SpringApplication.run(MsaStarboardApplication.class, args);
    }

}
